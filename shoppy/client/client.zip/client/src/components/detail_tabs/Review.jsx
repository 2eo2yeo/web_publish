import React from 'react';
import ReviewTop from './ReviewTop';
import ReviewList from './ReviewList';

export default function Review() {
    return (
        <div>
            <ReviewTop />
            <ReviewList />
        </div>
    );
}

